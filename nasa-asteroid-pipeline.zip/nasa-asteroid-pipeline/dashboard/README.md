# Dashboard — Tableau Visualization

## What it does
Connects Tableau Public to the asteroid data exported from Hive
and visualizes three key charts:

1. **Hazardous vs Non-Hazardous** — Bar chart showing count of safe vs dangerous asteroids
2. **Velocity Scatter Plot** — Circle chart colored by hazard status, sized by velocity
3. **Miss Distance Chart** — Horizontal bars showing how close each asteroid came to Earth

## Setup

### 1. Export data from Hive
```bash
echo "id,name,hazardous,magnitude,diameter_km_min,diameter_km_max,velocity_km_s,miss_dist_km,close_approach,orbiting_body" > ~/shared/asteroids.csv

hive -e "SELECT id, name, hazardous, magnitude, diameter_km_min, diameter_km_max,
  velocity_km_s, miss_dist_km, close_approach, orbiting_body
  FROM asteroids" | sed 's/\t/,/g' >> ~/shared/asteroids.csv
```

### 2. Open in Tableau Public
1. Open Tableau Public on Windows
2. Click **Connect to Data** → **Text file**
3. Navigate to shared folder → select `asteroids.csv`
4. Click **Go to Worksheet**

## Chart 1 — Hazardous vs Non-Hazardous
- Drag **Hazardous** → Columns
- Drag **Id** → Rows, change aggregation to **Count**
- Change mark type to **Bar**

## Chart 2 — Velocity Scatter Plot
- New sheet
- Drag **Name** → Columns
- Drag **Velocity Km S** → Rows
- Change mark type to **Circle**
- Drag **Hazardous** → Color
- Drag **Velocity Km S** → Size

## Chart 3 — Miss Distance
- New sheet
- Drag **Name** → Rows
- Drag **Miss Dist Km** → Columns
- Drag **Hazardous** → Color
- Click sort descending

## Dashboard
1. Click **New Dashboard** tab at bottom
2. Drag all 3 sheets onto the dashboard canvas
3. Add title: "NASA Asteroid Real-Time Tracking Dashboard"

## Key insights from live data (June 12, 2026)
- 2 hazardous asteroids detected: `388945 (2008 TZ3)` and `530520 (2011 LT17)`
- Closest miss: `530520 (2011 LT17)` at only 6,155,491 km from Earth
- Fastest: `(2002 UQ12)` at 35.3 km/s = 127,000 km/h
