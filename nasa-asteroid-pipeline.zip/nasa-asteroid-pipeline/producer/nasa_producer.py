#!/usr/bin/env python3
"""
nasa_producer.py
----------------
Polls NASA/JPL NeoWs API every 60 seconds and pushes live asteroid
close-approach data to a Kafka topic ('asteroids').

Author : Talentum | CDAC DBDA Project
API    : https://api.nasa.gov/neo/rest/v1/feed
"""

import requests
import json
import time
from kafka import KafkaProducer
from datetime import datetime, timedelta

# ── CONFIG ────────────────────────────────────────────────────────────────────
KAFKA_BROKER  = 'localhost:9092'
TOPIC         = 'asteroids'
NASA_API_KEY  = 'YOUR_NASA_API_KEY_HERE'   # Get free key at api.nasa.gov
POLL_INTERVAL = 60                          # Fetch every 60 seconds
# ─────────────────────────────────────────────────────────────────────────────

producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)


def fetch_asteroids():
    """Call NASA NeoWs API and return raw JSON response."""
    today    = datetime.today().strftime('%Y-%m-%d')
    tomorrow = (datetime.today() + timedelta(days=1)).strftime('%Y-%m-%d')

    url = (
        f"https://api.nasa.gov/neo/rest/v1/feed"
        f"?start_date={today}&end_date={tomorrow}"
        f"&api_key={NASA_API_KEY}"
    )

    response = requests.get(url, timeout=10)
    response.raise_for_status()   # Raise exception on HTTP errors
    return response.json()


def flatten_asteroid(asteroid):
    """
    Flatten NASA's deeply nested JSON into a simple flat dict.
    This makes Spark schema enforcement much easier downstream.

    NASA raw JSON structure:
        asteroid
          └── close_approach_data[0]
                ├── relative_velocity.kilometers_per_second
                ├── miss_distance.kilometers
                ├── close_approach_date
                └── orbiting_body
    """
    ca = asteroid['close_approach_data'][0]   # First close approach entry

    return {
        'id'              : asteroid['id'],
        'name'            : asteroid['name'],
        'hazardous'       : asteroid['is_potentially_hazardous_asteroid'],
        'magnitude'       : asteroid['absolute_magnitude_h'],
        'diameter_km_min' : asteroid['estimated_diameter']['kilometers']['estimated_diameter_min'],
        'diameter_km_max' : asteroid['estimated_diameter']['kilometers']['estimated_diameter_max'],
        'velocity_km_s'   : ca['relative_velocity']['kilometers_per_second'],
        'miss_dist_km'    : ca['miss_distance']['kilometers'],
        'close_approach'  : ca['close_approach_date'],
        'orbiting_body'   : ca['orbiting_body'],
        'fetched_at'      : datetime.utcnow().isoformat()
    }


# ── MAIN LOOP ─────────────────────────────────────────────────────────────────
print(f"[NASA Producer] Started → Kafka topic: '{TOPIC}' on {KAFKA_BROKER}")
print(f"[NASA Producer] Polling every {POLL_INTERVAL} seconds...\n")

while True:
    try:
        data  = fetch_asteroids()
        neos  = data['near_earth_objects']
        count = 0

        for date, asteroids in neos.items():
            for asteroid in asteroids:
                flat = flatten_asteroid(asteroid)
                producer.send(TOPIC, value=flat)
                count += 1

        producer.flush()
        print(f"[{datetime.utcnow().isoformat()}] ✓ Sent {count} asteroids to Kafka")

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] NASA API request failed: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")

    time.sleep(POLL_INTERVAL)
