# Producer — NASA API → Kafka

## What it does
`nasa_producer.py` polls the NASA NeoWs (Near Earth Object Web Service) API every 60 seconds
and pushes each asteroid record as a flat JSON message to the Kafka `asteroids` topic.

## Setup

### 1. Get your NASA API key
- Go to: https://api.nasa.gov
- Click "Generate API Key"
- Fill name + email → key arrives instantly

### 2. Add your key to the script
Open `nasa_producer.py` and replace:
```python
NASA_API_KEY = 'YOUR_NASA_API_KEY_HERE'
```
with your actual key.

### 3. Install dependencies
```bash
pip install requests kafka-python
```

### 4. Run the producer
```bash
python3 nasa_producer.py
```

## Expected output
```
[NASA Producer] Started → Kafka topic: 'asteroids' on localhost:9092
[NASA Producer] Polling every 60 seconds...

[2026-06-12T15:16:18.411274] ✓ Sent 9 asteroids to Kafka
[2026-06-12T15:17:18.411274] ✓ Sent 9 asteroids to Kafka
```

## Verify in Kafka
```bash
~/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --topic asteroids \
  --from-beginning
```

## Sample record
```json
{
  "id": "2388945",
  "name": "388945 (2008 TZ3)",
  "hazardous": true,
  "magnitude": 20.44,
  "diameter_km_min": 0.2170475943,
  "diameter_km_max": 0.4853331752,
  "velocity_km_s": "7.4845318069",
  "miss_dist_km": "16794474.620684591",
  "close_approach": "2026-06-12",
  "orbiting_body": "Earth",
  "fetched_at": "2026-06-12T15:16:18.421864"
}
```

## Notes
- Free NASA API allows 30 requests/hour — our 60s polling uses 1/minute = 60/hour, so stay within limits
- The `flatten_asteroid()` function converts NASA's nested JSON into a simple flat dict for easy Spark schema enforcement
