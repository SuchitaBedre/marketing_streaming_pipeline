-- ============================================================
-- create_table.sql
-- Creates an EXTERNAL Hive table over Parquet files on HDFS.
--
-- EXTERNAL = Hive does not own the data.
-- If you DROP TABLE, Parquet files stay safe on HDFS.
-- Spark keeps writing; Hive just reads.
--
-- Author: Talentum | CDAC DBDA Project
-- ============================================================

CREATE EXTERNAL TABLE IF NOT EXISTS asteroids (
  id               STRING,
  name             STRING,
  hazardous        BOOLEAN,
  magnitude        DOUBLE,
  diameter_km_min  DOUBLE,
  diameter_km_max  DOUBLE,
  velocity_km_s    STRING,
  miss_dist_km     STRING,
  close_approach   STRING,
  orbiting_body    STRING,
  fetched_at       STRING
)
STORED AS PARQUET
LOCATION 'hdfs://localhost:9000/user/talentum/asteroids/';
