-- ============================================================
-- queries.sql
-- Useful Hive SQL queries for asteroid data analysis.
--
-- Author: Talentum | CDAC DBDA Project
-- ============================================================


-- ── 1. Total asteroid count ───────────────────────────────
SELECT COUNT(*) AS total_asteroids
FROM asteroids;


-- ── 2. Hazardous vs Non-Hazardous count ──────────────────
SELECT
  hazardous,
  COUNT(*) AS count
FROM asteroids
GROUP BY hazardous;


-- ── 3. All potentially hazardous asteroids ───────────────
SELECT
  name,
  velocity_km_s,
  miss_dist_km,
  close_approach
FROM asteroids
WHERE hazardous = true
ORDER BY CAST(miss_dist_km AS DOUBLE) ASC;


-- ── 4. Top 5 fastest asteroids ───────────────────────────
SELECT
  name,
  velocity_km_s,
  hazardous
FROM asteroids
ORDER BY CAST(velocity_km_s AS DOUBLE) DESC
LIMIT 5;


-- ── 5. Top 5 closest approaches ──────────────────────────
SELECT
  name,
  miss_dist_km,
  hazardous,
  close_approach
FROM asteroids
ORDER BY CAST(miss_dist_km AS DOUBLE) ASC
LIMIT 5;


-- ── 6. Largest asteroids by diameter ─────────────────────
SELECT
  name,
  ROUND(diameter_km_max, 4) AS max_diameter_km,
  hazardous
FROM asteroids
ORDER BY diameter_km_max DESC
LIMIT 10;


-- ── 7. Unique asteroids (deduplicated) ───────────────────
SELECT
  COUNT(DISTINCT id) AS unique_asteroids
FROM asteroids;


-- ── 8. Hazard summary statistics ─────────────────────────
SELECT
  hazardous,
  COUNT(*)                                        AS count,
  ROUND(AVG(CAST(velocity_km_s AS DOUBLE)), 2)   AS avg_velocity_km_s,
  ROUND(AVG(CAST(miss_dist_km  AS DOUBLE)), 0)   AS avg_miss_dist_km,
  ROUND(AVG(magnitude), 2)                        AS avg_magnitude
FROM asteroids
GROUP BY hazardous;


-- ── 9. Export to CSV for Tableau ─────────────────────────
-- Run this from shell:
-- hive -e "SELECT id, name, hazardous, magnitude, diameter_km_min,
--   diameter_km_max, velocity_km_s, miss_dist_km, close_approach, orbiting_body
--   FROM asteroids" | sed 's/\t/,/g' > asteroids_export.csv
