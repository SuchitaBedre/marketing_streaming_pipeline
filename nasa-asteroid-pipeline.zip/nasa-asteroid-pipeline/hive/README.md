# Hive — SQL on Parquet Data Lake

## What it does
Apache Hive sits on top of your HDFS Parquet files and lets you query them
with standard SQL — without moving or copying any data.

## Setup

### 1. Start MySQL and Hive Metastore
```bash
sudo service mysql start
~/run-hivemetastore.sh -s start &
sleep 15
```

### 2. Start HiveServer2 (needed for JDBC / Tableau connection)
```bash
hive --service hiveserver2 &
sleep 20

# Verify it's listening
netstat -tlnp | grep 10000
```

### 3. Create the external table
```bash
hive -f hive/create_table.sql
```

### 4. Run analysis queries
```bash
hive -f hive/queries.sql
```

## Key concept — EXTERNAL table
```sql
CREATE EXTERNAL TABLE asteroids (...)
STORED AS PARQUET
LOCATION 'hdfs://localhost:9000/user/talentum/asteroids/';
```
- `EXTERNAL` means Hive does NOT own the files
- Dropping the table leaves your Parquet data intact on HDFS
- Spark writes → Hive reads → clean separation of concerns

## Verify table exists
```bash
hive -e "SHOW TABLES;"
hive -e "DESCRIBE asteroids;"
hive -e "SELECT COUNT(*) FROM asteroids;"
```

## Export to CSV for Tableau
```bash
echo "id,name,hazardous,magnitude,diameter_km_min,diameter_km_max,velocity_km_s,miss_dist_km,close_approach,orbiting_body" > asteroids.csv

hive -e "SELECT id, name, hazardous, magnitude, diameter_km_min, diameter_km_max,
  velocity_km_s, miss_dist_km, close_approach, orbiting_body
  FROM asteroids" | sed 's/\t/,/g' >> asteroids.csv
```
