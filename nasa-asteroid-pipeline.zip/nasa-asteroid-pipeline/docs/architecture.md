# Architecture — Deep Dive

## Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        BigDataVM (Ubuntu 64-bit)                │
│                                                                 │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐ │
│  │ NASA API │───▶│  Kafka   │───▶│  Spark   │───▶│  HDFS    │ │
│  │ Producer │    │ Broker   │    │Streaming │    │ Parquet  │ │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘ │
│                                                       │         │
│                  ┌──────────┐    ┌──────────┐         │         │
│                  │ Tableau  │◀───│   Hive   │◀────────┘         │
│                  │Dashboard │    │  SQL     │                   │
│                  └──────────┘    └──────────┘                   │
└─────────────────────────────────────────────────────────────────┘
```

## Layer 1 — NASA/JPL API (Data Source)

**What:** NASA's free NeoWs (Near Earth Object Web Service) REST API  
**Endpoint:** `https://api.nasa.gov/neo/rest/v1/feed`  
**Parameters:** `start_date`, `end_date`, `api_key`  
**Rate limit:** 30 requests/hour (free tier)  
**Data:** JSON containing asteroid telemetry — name, size, velocity, miss distance, hazard status

**Why polling instead of webhooks?**  
NASA's API is pull-based — it doesn't push data. Our producer polls every 60 seconds,
which comfortably stays within the rate limit while keeping data fresh.

---

## Layer 2 — Apache Kafka (Message Queue)

**What:** Distributed publish-subscribe messaging system  
**Topic:** `asteroids` with 3 partitions, replication-factor 1  
**Producer:** `nasa_producer.py` using `kafka-python` library  
**Consumer:** PySpark readStream via Kafka connector  

**Why Kafka?**  
- **Fault tolerance:** If Spark crashes, Kafka retains messages. When Spark restarts,
  it reads from the last committed offset — no data lost.
- **Decoupling:** Producer and consumer run independently. You can restart Spark
  without affecting the producer.
- **Scalability:** 3 partitions allow 3 parallel Spark tasks to read simultaneously.

**Key Kafka concepts used:**
- **Topic:** Named channel (`asteroids`) where messages are published
- **Partition:** Sub-division of a topic for parallelism (3 partitions)
- **Offset:** Sequential ID for each message — used for fault tolerance
- **Consumer group:** Spark reads as a consumer group, tracking its own offsets

---

## Layer 3 — PySpark Structured Streaming (Processing)

**What:** Real-time distributed stream processing  
**Mode:** Micro-batch (trigger every 15 seconds)  
**Input:** Kafka `asteroids` topic  
**Output:** Parquet files on HDFS  

**Why Structured Streaming over DStreams?**  
Structured Streaming is the modern Spark API (Spark 2.0+). It:
- Works with DataFrames (not low-level RDDs)
- Supports exactly-once processing with checkpointing
- Handles schema enforcement natively
- Integrates directly with Hive and Parquet

**Schema enforcement:** We define a `StructType` schema that maps each JSON field
to a typed column. This prevents corruption if NASA's API sends malformed data.
`StringType` is used for velocity and distance to preserve full decimal precision
(orbital mechanics requires this — `DoubleType` can introduce rounding errors).

**Checkpoint:** Spark writes Kafka offsets to HDFS after each micro-batch.
On restart, it reads the checkpoint and resumes from the exact last offset.

---

## Layer 4 — Apache Parquet + HDFS (Storage)

**What:** Columnar file format stored on Hadoop Distributed File System  
**Location:** `hdfs://localhost:9000/user/talentum/asteroids/`  
**Compression:** Snappy (automatic, ~70% reduction vs raw JSON)  
**Files:** One file per Kafka partition per micro-batch  

**Why Parquet over CSV/JSON?**

| Format | Storage | Query speed | Schema |
|--------|---------|-------------|--------|
| JSON   | Large   | Slow (full scan) | None |
| CSV    | Medium  | Slow (full scan) | None |
| Parquet| Small   | Fast (column pruning) | Embedded |

Parquet stores each column separately. A query like `SELECT velocity_km_s WHERE hazardous = true`
only reads 2 columns — skipping the other 9 entirely. At scale this is transformative.

**HDFS** provides fault tolerance via block replication. Even on a single-node VM,
it provides the standard Hadoop filesystem API that Hive and Spark expect.

---

## Layer 5 — Apache Hive (SQL Query Layer)

**What:** SQL warehouse that maps tables to HDFS files  
**Type:** External table (Spark owns the data, Hive just reads it)  
**Metastore:** MySQL-backed (stores table definitions, column types, HDFS locations)  
**Execution:** MapReduce (default) — can switch to Spark or Tez for speed  

**Why External table?**  
An EXTERNAL table means Hive holds only metadata (what the table looks like and where
the files are). The actual Parquet files remain on HDFS. If you `DROP TABLE asteroids`,
Hive deletes only its metadata entry — the Parquet files stay untouched, and Spark
keeps writing new ones. This is the correct production pattern.

**How Hive reads Parquet:**  
Hive uses the Parquet SerDe (serializer/deserializer) to read `.snappy.parquet` files
directly. No data conversion or copying needed. The schema in `CREATE TABLE` must
match the Parquet file schema exactly.

---

## Layer 6 — Tableau (Visualization)

**What:** Interactive BI dashboard  
**Connection:** CSV export from Hive  
**Charts:**
1. Hazardous vs Non-Hazardous count (bar chart)
2. Velocity by asteroid (scatter plot, colored by hazard)
3. Miss distance ranking (horizontal bar, colored by hazard)

**Production alternative:** Connect Tableau directly to Hive via JDBC using
`hive-jdbc-2.3.6-standalone.jar` and HiveServer2 on port 10000. The CSV export
approach is used here for simplicity on the student VM.

---

## Data Flow Summary

```
1. nasa_producer.py calls NASA API every 60s
2. Flattens nested JSON into flat dict
3. Sends to Kafka 'asteroids' topic via kafka-python
4. PySpark readStream reads from Kafka offset by offset
5. from_json() parses bytes using StructType schema
6. writeStream writes Parquet to HDFS every 15s
7. Hive EXTERNAL TABLE points at HDFS location
8. SQL queries read Parquet via Hive metastore
9. CSV exported → Tableau dashboard visualizes results
```
