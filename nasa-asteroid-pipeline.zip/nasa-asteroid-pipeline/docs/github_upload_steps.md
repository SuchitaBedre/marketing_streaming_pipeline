# Steps to Upload This Project to GitHub

## On your VM — Terminal

### Step 1 — Install Git (if not already)
```bash
git --version
# If not installed:
sudo apt-get install git -y
```

### Step 2 — Configure Git with your details
```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

### Step 3 — Create a new repo on GitHub
- Go to https://github.com
- Click "+" → "New repository"
- Name it: `nasa-asteroid-pipeline`
- Set to Public
- Do NOT add README (we have our own)
- Click "Create repository"
- Copy the repo URL shown e.g. `https://github.com/yourname/nasa-asteroid-pipeline.git`

### Step 4 — Copy project files to VM
Copy all files from this folder to your VM:
```bash
mkdir -p ~/nasa-asteroid-pipeline
cd ~/nasa-asteroid-pipeline
```

Then create each file using gedit — or copy from shared folder.

### Step 5 — Add your NASA API key to producer
```bash
gedit ~/nasa-asteroid-pipeline/producer/nasa_producer.py &
# Replace YOUR_NASA_API_KEY_HERE with your actual key
```

### Step 6 — Initialize Git and push
```bash
cd ~/nasa-asteroid-pipeline

git init
git add .
git commit -m "Initial commit: NASA asteroid real-time big data pipeline"
git branch -M main
git remote add origin https://github.com/yourname/nasa-asteroid-pipeline.git
git push -u origin main
```

### Step 7 — Verify on GitHub
- Go to your GitHub repo URL
- You should see all files and folders
- README.md renders automatically on the repo homepage

## Important — keep your API key safe!
Before pushing, make sure `nasa_producer.py` does NOT have your real API key.
Either:
- Replace it back with `YOUR_NASA_API_KEY_HERE` before committing, OR
- Add it to `.gitignore` via a config file

### Create .gitignore
```bash
cat > ~/nasa-asteroid-pipeline/.gitignore << 'EOF'
*.pyc
__pycache__/
*.csv
checkpoint/
.env
config.ini
EOF
```

## Future updates — push new changes
```bash
cd ~/nasa-asteroid-pipeline
git add .
git commit -m "Add Tableau dashboard screenshots"
git push
```
