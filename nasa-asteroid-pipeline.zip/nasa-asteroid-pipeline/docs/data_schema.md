# Data Schema

## Asteroid Record

Each record flowing through the pipeline represents one asteroid making a close approach to Earth.

| Field | Type | Source | Description |
|-------|------|--------|-------------|
| `id` | STRING | NASA API | Unique SPK-ID assigned by NASA's JPL |
| `name` | STRING | NASA API | IAU designation e.g. `388945 (2008 TZ3)` |
| `hazardous` | BOOLEAN | NASA API | `true` if classified as Potentially Hazardous Asteroid |
| `magnitude` | DOUBLE | NASA API | Absolute magnitude H (lower = larger/brighter) |
| `diameter_km_min` | DOUBLE | NASA API | Estimated minimum diameter in kilometers |
| `diameter_km_max` | DOUBLE | NASA API | Estimated maximum diameter in kilometers |
| `velocity_km_s` | STRING | NASA API | Relative velocity at closest approach (km/s) |
| `miss_dist_km` | STRING | NASA API | Miss distance from Earth center (km) |
| `close_approach` | STRING | NASA API | Date of closest approach (YYYY-MM-DD) |
| `orbiting_body` | STRING | NASA API | Body being orbited — almost always `Earth` |
| `fetched_at` | STRING | Producer | UTC ISO timestamp when record was fetched |

## Why STRING for velocity and miss_dist?

Orbital mechanics requires very high decimal precision.  
NASA returns these as strings like `"7.4845318069"`.

Converting to `DoubleType` introduces IEEE 754 floating-point rounding:
```
"7.4845318069" → DoubleType → 7.484531806899999  ← WRONG
"7.4845318069" → StringType → "7.4845318069"     ← CORRECT
```

For display and sorting we cast to DOUBLE in SQL:
```sql
ORDER BY CAST(velocity_km_s AS DOUBLE) DESC
```

But the stored value stays as the exact string NASA provided.

## Sample Record

```json
{
  "id": "2388945",
  "name": "388945 (2008 TZ3)",
  "hazardous": true,
  "magnitude": 20.44,
  "diameter_km_min": 0.2170475943,
  "diameter_km_max": 0.4853331752,
  "velocity_km_s": "7.4845318069",
  "miss_dist_km": "16794474.620684591",
  "close_approach": "2026-06-12",
  "orbiting_body": "Earth",
  "fetched_at": "2026-06-12T15:16:18.421864"
}
```

## Potentially Hazardous Asteroid (PHA) Classification

NASA classifies an asteroid as **Potentially Hazardous** if:
- It comes within **0.05 AU** (7.5 million km) of Earth's orbit, AND
- Its diameter is estimated at **140 meters or larger**

This does NOT mean imminent impact — it means the orbit *could* bring it
dangerously close in the future and it's large enough to cause regional damage.

## Magnitude to Size conversion

Absolute magnitude `H` relates to size approximately as:
```
diameter (km) ≈ 1329 / sqrt(albedo) × 10^(-H/5)
```
Where albedo (reflectivity) is typically 0.14 for dark asteroids, 0.25 for bright.

This is why NASA gives `estimated_diameter_min` and `estimated_diameter_max` —
the uncertainty comes from unknown albedo.
