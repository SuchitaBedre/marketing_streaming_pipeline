# Spark — Kafka → HDFS Parquet

## What it does
`nasa_spark.py` is a PySpark Structured Streaming job that reads asteroid JSON
from the Kafka `asteroids` topic, enforces a strict schema, and writes clean
Parquet files to HDFS every 15 seconds.

## How to run

### Important — unset Jupyter conflict first
Your VM has `PYSPARK_DRIVER_PYTHON` set to Jupyter by default.
Always run these two lines before spark-submit:
```bash
unset PYSPARK_DRIVER_PYTHON
unset PYSPARK_DRIVER_PYTHON_OPTS
```

### Run the Spark job
```bash
unset PYSPARK_DRIVER_PYTHON
unset PYSPARK_DRIVER_PYTHON_OPTS

spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.5 \
  spark/nasa_spark.py
```

## Verify output on HDFS
```bash
# List Parquet files written
hdfs dfs -ls /user/talentum/asteroids/

# Read back and verify in PySpark shell
unset PYSPARK_DRIVER_PYTHON
unset PYSPARK_DRIVER_PYTHON_OPTS
pyspark

df = spark.read.parquet("hdfs://localhost:9000/user/talentum/asteroids/")
df.show(5, truncate=False)
df.count()
```

## Expected HDFS output
```
Found 3 items
-rw-r--r-- talentum part-00000-xxx.snappy.parquet
-rw-r--r-- talentum part-00001-xxx.snappy.parquet
-rw-r--r-- talentum part-00002-xxx.snappy.parquet
```
3 files = 3 Kafka partitions processed in parallel.

## Why Parquet?
- Columnar storage → only reads columns needed for a query
- Snappy compression → ~70% smaller than raw JSON
- Schema embedded → Hive can read without DDL mapping
- Partition pruning → Hive skips irrelevant files automatically

## Checkpoint
The `checkpointLocation` on HDFS stores Kafka offsets after each micro-batch.
If Spark crashes and restarts, it resumes exactly where it left off — no data loss.
