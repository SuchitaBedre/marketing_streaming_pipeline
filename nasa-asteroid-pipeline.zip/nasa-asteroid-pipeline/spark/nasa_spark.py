#!/usr/bin/env python3
"""
nasa_spark.py
-------------
PySpark Structured Streaming job that:
  1. Reads live asteroid JSON from Kafka topic 'asteroids'
  2. Parses and enforces a strict schema (prevents float rounding errors)
  3. Writes output as Parquet files to HDFS (partitioned, Snappy compressed)

Author : Talentum | CDAC DBDA Project
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import (
    StructType, StructField,
    StringType, BooleanType, DoubleType
)

# ── SCHEMA ────────────────────────────────────────────────────────────────────
# Must match exactly what nasa_producer.py sends.
# Using StringType for velocity and miss_dist to avoid float precision loss
# in orbital mechanics calculations.
schema = StructType([
    StructField("id",               StringType(),  True),
    StructField("name",             StringType(),  True),
    StructField("hazardous",        BooleanType(), True),
    StructField("magnitude",        DoubleType(),  True),
    StructField("diameter_km_min",  DoubleType(),  True),
    StructField("diameter_km_max",  DoubleType(),  True),
    StructField("velocity_km_s",    StringType(),  True),   # Keep as String → no float rounding
    StructField("miss_dist_km",     StringType(),  True),   # Keep as String → no float rounding
    StructField("close_approach",   StringType(),  True),
    StructField("orbiting_body",    StringType(),  True),
    StructField("fetched_at",       StringType(),  True),
])

# ── CONFIG ────────────────────────────────────────────────────────────────────
KAFKA_BROKER      = "localhost:9092"
KAFKA_TOPIC       = "asteroids"
HDFS_OUTPUT_PATH  = "hdfs://localhost:9000/user/talentum/asteroids/"
HDFS_CHECKPOINT   = "hdfs://localhost:9000/user/talentum/asteroids_checkpoint/"
TRIGGER_INTERVAL  = "15 seconds"
# ─────────────────────────────────────────────────────────────────────────────

# ── SPARK SESSION ─────────────────────────────────────────────────────────────
spark = SparkSession.builder \
    .appName("NASAAsteroidPipeline") \
    .enableHiveSupport() \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

print("[NASA Spark] Session started")
print(f"[NASA Spark] Reading from Kafka topic: '{KAFKA_TOPIC}'")
print(f"[NASA Spark] Writing Parquet to: {HDFS_OUTPUT_PATH}")

# ── STEP 1: READ FROM KAFKA ───────────────────────────────────────────────────
# Kafka returns raw bytes in 'value' column.
# We cast to string first, then parse as JSON using our schema.
raw = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_BROKER) \
    .option("subscribe", KAFKA_TOPIC) \
    .option("startingOffsets", "earliest") \
    .load()

# ── STEP 2: PARSE JSON WITH SCHEMA ───────────────────────────────────────────
asteroids = raw.select(
    from_json(col("value").cast("string"), schema).alias("data")
).select("data.*")

# ── STEP 3: WRITE TO HDFS AS PARQUET ─────────────────────────────────────────
# outputMode("append") — only new rows each micro-batch
# format("parquet")    — columnar compressed storage
# checkpointLocation   — enables fault tolerance; Spark resumes from last offset
query = asteroids.writeStream \
    .trigger(processingTime=TRIGGER_INTERVAL) \
    .outputMode("append") \
    .format("parquet") \
    .option("path", HDFS_OUTPUT_PATH) \
    .option("checkpointLocation", HDFS_CHECKPOINT) \
    .start()

print(f"[NASA Spark] Streaming query started. Micro-batch every {TRIGGER_INTERVAL}")
print("[NASA Spark] Writing to HDFS... (Ctrl+C to stop)\n")

query.awaitTermination()
