# 🚀 Real-Time Big Data Pipeline for NASA/JPL Planetary Defense Tracking

> CDAC | DBDA Course Project | Domain: Big Data Engineering & Stream Processing

---

## 📌 What is This Project?

NASA tracks over **1.3 million asteroids, comets, and Near-Earth Objects (NEOs)** that come close to Earth.  
This project builds an **end-to-end real-time big data pipeline** that:

- Pulls **live asteroid data** from NASA's public API every 60 seconds
- Buffers it through **Apache Kafka** for fault-tolerant ingestion
- Processes it in real-time using **PySpark Structured Streaming**
- Stores it efficiently as **Parquet files on HDFS**
- Queries it using **Apache Hive SQL**
- Visualizes it on an **interactive Tableau dashboard**

---

## 🏗️ Pipeline Architecture

```
NASA/JPL API → Kafka (Producer) → Spark Streaming → Parquet on HDFS → Hive → Tableau
     ↑                ↑                  ↑                 ↑             ↑        ↑
  Live data      Fault-tolerant     Schema enforce    Columnar store   SQL layer  Dashboard
```

| Layer | Technology | Role |
|-------|-----------|------|
| 1 — Ingest | NASA/JPL REST API | Live NEO telemetry via HTTP polling |
| 2 — Queue | Apache Kafka | Fault-tolerant message buffer |
| 3 — Process | PySpark Structured Streaming | Real-time schema-enforced processing |
| 4 — Store | Apache Parquet + HDFS | Compressed columnar data lake |
| 5 — Query | Apache Hive | SQL warehouse over data lake |
| 6 — Visualize | Tableau Public | Interactive asteroid dashboard |

---

## 🛠️ Technology Stack

- **Apache Kafka 2.x** — Message queue with 3-partition `asteroids` topic
- **Apache Spark 2.4.5** — PySpark Structured Streaming with micro-batch processing
- **Apache Hadoop 2.7.x / HDFS** — Distributed file system for Parquet storage
- **Apache Hive 2.3.6** — SQL query layer over Parquet data lake
- **Python 3** — NASA API producer using `requests` and `kafka-python`
- **Tableau Public** — Interactive visualization dashboard
- **NASA NeoWs API** — Free public REST API for Near-Earth Object data

---

## 📁 Project Structure

```
nasa-asteroid-pipeline/
│
├── README.md                        ← You are here
│
├── producer/
│   ├── nasa_producer.py             ← Polls NASA API, pushes to Kafka
│   └── README.md                    ← Producer setup instructions
│
├── spark/
│   ├── nasa_spark.py                ← PySpark Structured Streaming job
│   └── README.md                    ← Spark job instructions
│
├── hive/
│   ├── create_table.sql             ← Hive external table DDL
│   ├── queries.sql                  ← Useful analysis queries
│   └── README.md                    ← Hive setup instructions
│
├── dashboard/
│   ├── asteroids_sample.csv         ← Sample data for Tableau
│   └── README.md                    ← Dashboard instructions
│
├── scripts/
│   ├── start_pipeline.sh            ← One-click pipeline startup script
│   └── stop_pipeline.sh             ← One-click pipeline shutdown script
│
└── docs/
    ├── architecture.md              ← Detailed architecture explanation
    └── data_schema.md               ← Full data schema documentation
```

---

## ⚡ Quick Start

### Prerequisites
- BigDataVM (Ubuntu 64-bit) with Hadoop, Kafka, Spark, Hive installed
- NASA API key from [api.nasa.gov](https://api.nasa.gov)
- Python 3 with `requests` and `kafka-python` libraries

### Step 1 — Start all services
```bash
# Start Hadoop
~/hadoop/sbin/start-dfs.sh
~/hadoop/sbin/start-yarn.sh

# Start Zookeeper (Terminal 1)
~/kafka/bin/zookeeper-server-start.sh ~/kafka/config/zookeeper.properties

# Start Kafka (Terminal 2)
~/kafka/bin/kafka-server-start.sh ~/kafka/config/server.properties
```

### Step 2 — Create Kafka topic
```bash
~/kafka/bin/kafka-topics.sh --create \
  --topic asteroids \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 1
```

### Step 3 — Start the NASA producer
```bash
# Add your API key in producer/nasa_producer.py first
python3 producer/nasa_producer.py
```

### Step 4 — Start Spark Streaming job
```bash
unset PYSPARK_DRIVER_PYTHON
unset PYSPARK_DRIVER_PYTHON_OPTS
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.5 \
  spark/nasa_spark.py
```

### Step 5 — Create Hive table
```bash
~/run-hivemetastore.sh -s start &
sleep 15
hive -f hive/create_table.sql
```

### Step 6 — Query your data
```bash
hive -f hive/queries.sql
```

---

## 📊 Sample Results

From a live pipeline run on June 12, 2026:

| Metric | Value |
|--------|-------|
| Total asteroids ingested | 207+ |
| Hazardous asteroids detected | 2 |
| Fastest asteroid | (2002 UQ12) at 35.3 km/s |
| Closest approach | 530520 (2011 LT17) at 6,155,491 km |
| Storage reduction vs JSON | ~70% via Parquet + Snappy |

---

## 👤 Author

**Talentum** | CDAC DBDA Program | June 2026

---

## 📄 License

This project is for educational purposes as part of the CDAC DBDA curriculum.  
NASA asteroid data is publicly available via [NASA Open APIs](https://api.nasa.gov).
