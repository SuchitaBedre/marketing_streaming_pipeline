#!/bin/bash
# ============================================================
# stop_pipeline.sh
# Gracefully shuts down all pipeline services.
#
# Usage: bash scripts/stop_pipeline.sh
#
# Author: Talentum | CDAC DBDA Project
# ============================================================

echo "=============================================="
echo "  NASA Asteroid Pipeline — Shutting Down"
echo "=============================================="

echo ""
echo "[1/4] Stopping Kafka broker..."
~/kafka/bin/kafka-server-stop.sh
sleep 3
echo "      Kafka stopped ✓"

echo ""
echo "[2/4] Stopping Zookeeper..."
~/kafka/bin/zookeeper-server-stop.sh
sleep 3
echo "      Zookeeper stopped ✓"

echo ""
echo "[3/4] Stopping YARN..."
~/hadoop/sbin/stop-yarn.sh
echo "      YARN stopped ✓"

echo ""
echo "[4/4] Stopping HDFS..."
~/hadoop/sbin/stop-dfs.sh
echo "      HDFS stopped ✓"

echo ""
echo "=============================================="
echo "  All services stopped. Pipeline is down."
echo "=============================================="
jps
