#!/bin/bash
# ============================================================
# start_pipeline.sh
# One-click startup for the NASA Asteroid Pipeline.
# Run this script to bring up all services in the correct order.
#
# Usage: bash scripts/start_pipeline.sh
#
# Author: Talentum | CDAC DBDA Project
# ============================================================

echo "=============================================="
echo "  NASA Asteroid Pipeline — Starting Up"
echo "=============================================="

# ── Step 1: Start HDFS ────────────────────────────────────
echo ""
echo "[1/5] Starting HDFS..."
~/hadoop/sbin/start-dfs.sh
sleep 5
echo "      HDFS started ✓"

# ── Step 2: Start YARN ────────────────────────────────────
echo ""
echo "[2/5] Starting YARN..."
~/hadoop/sbin/start-yarn.sh
sleep 5
echo "      YARN started ✓"

# ── Step 3: Start Zookeeper ───────────────────────────────
echo ""
echo "[3/5] Starting Zookeeper..."
~/kafka/bin/zookeeper-server-start.sh ~/kafka/config/zookeeper.properties &
sleep 8
echo "      Zookeeper started ✓"

# ── Step 4: Start Kafka ───────────────────────────────────
echo ""
echo "[4/5] Starting Kafka broker..."
~/kafka/bin/kafka-server-start.sh ~/kafka/config/server.properties &
sleep 8
echo "      Kafka started ✓"

# ── Step 5: Start Hive Metastore ─────────────────────────
echo ""
echo "[5/5] Starting Hive Metastore..."
sudo service mysql start
~/run-hivemetastore.sh -s start &
sleep 10
echo "      Hive Metastore started ✓"

# ── Create Kafka topic (if not exists) ───────────────────
echo ""
echo "[+] Creating Kafka topic 'asteroids' (if not exists)..."
~/kafka/bin/kafka-topics.sh --create \
  --topic asteroids \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 1 2>/dev/null || echo "      Topic already exists ✓"

# ── Verify all services ───────────────────────────────────
echo ""
echo "=============================================="
echo "  Services Running (jps):"
echo "=============================================="
jps
echo ""
echo "=============================================="
echo "  All services started!"
echo ""
echo "  Next steps:"
echo "  1. Terminal 1: python3 producer/nasa_producer.py"
echo "  2. Terminal 2: unset PYSPARK_DRIVER_PYTHON && unset PYSPARK_DRIVER_PYTHON_OPTS"
echo "                 spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.5 spark/nasa_spark.py"
echo "  3. Terminal 3: hive -f hive/create_table.sql"
echo "  4. Terminal 3: hive -f hive/queries.sql"
echo "=============================================="
